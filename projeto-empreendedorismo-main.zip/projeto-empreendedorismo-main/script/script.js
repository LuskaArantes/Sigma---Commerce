let btnMobile = document.getElementById('btnMobile');
let nav = document.getElementById('nav')
let menu = document.getElementById('menu');

btnMobile.addEventListener('click', () =>{
    nav.classList.toggle('active')
})
